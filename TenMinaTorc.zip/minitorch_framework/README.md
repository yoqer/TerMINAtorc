# MiniTorch Framework

**Framework Completo para Deep Learning, Reinforcement Learning y Modelos Relacionales**

Construido sobre **MiniTorch Lite**, este framework proporciona arquitecturas de vanguardia y herramientas avanzadas para entrenar modelos de gran escala.

---

## Características Principales

### 🧠 Transformer RLM (Reinforcement Learning Model)
- Multi-Head Self-Attention con hasta **64 cabezas**
- Feed-Forward Networks con hasta **8192 neuronas**
- Soporte para secuencias de hasta **8192 tokens**
- Layer Normalization y Residual Connections
- Positional Encoding sinusoidal

### 🎮 Reinforcement Learning
- **Q-Learning (DQN)**: Deep Q-Network con Experience Replay
- **PPO**: Proximal Policy Optimization con Actor-Critic
- Replay Buffer con capacidad de 100,000 transiciones
- Epsilon-greedy exploration

### 🔗 Relational Networks
- Razonamiento sobre relaciones entre objetos
- Módulo de relación para procesar pares
- Agregación de relaciones para salida final

### ⚡ vLLM (Virtual LLM)
- **KV-Cache**: Optimización de generación autoregressiva
- **Continuous Batching**: Procesamiento eficiente de múltiples requests
- **Top-K y Top-P Sampling**: Control de generación
- Inferencia hasta **10x más rápida** que generación estándar

### 🎯 Control de Entrenamiento
- **[NEW] Early Stop**: Salto tras 12 iteraciones sin mejora
- **Límite de Tokens**: Corte automático a N tokens
- **Checkpoints**: Guardado y reanudación de entrenamiento
- **Máximo 69 repeticiones** por defecto

---

## Instalación

### 1. Instalar MiniTorch Lite

```bash
# Desde el ZIP
unzip minitorch_lite.zip
cd minitorch_lite
pip install -e .
```

### 2. Instalar el Framework

```bash
# Extraer el framework
unzip minitorch_framework.zip
cd minitorch_framework
```

### 3. Dependencias Opcionales

```bash
# Para aceleración
pip install numba jax jaxlib

# Para integración con otros frameworks
pip install tensorflow torch
```

---

## Uso Rápido

### Entrenar Modelo Completo

```bash
python examples/train_complete_model.py --config config.json --epochs 10 --generate
```

### Ejemplo Básico

```python
import sys
sys.path.insert(0, '/home/ubuntu')
sys.path.insert(0, '/home/ubuntu/minitorch_framework')

from models.transformer_rlm import TransformerRLM
from minitorch_lite import Adam

# Crear modelo
model = TransformerRLM(
    vocab_size=50000,
    d_model=512,
    num_heads=8,
    num_layers=6,
    d_ff=2048
)

# Optimizador
optimizer = Adam(model.parameters(), lr=0.0001)

# Forward pass
import numpy as np
inputs = np.random.randint(0, 50000, (2, 128))
logits = model.forward(inputs)

print(f"Salida: {logits.shape}")  # (2, 128, 50000)
```

---

## Estructura del Proyecto

```
minitorch_framework/
├── models/
│   └── transformer_rlm.py          # Transformer RLM
├── rl/
│   └── reinforcement_learning.py   # Q-Learning, PPO
├── vllm/
│   └── relational_vllm.py          # Relational Networks, vLLM
├── examples/
│   └── train_complete_model.py     # Script de entrenamiento
├── docs/
│   └── MANUAL_DE_USO.md            # Manual completo
├── config.json                      # Configuración de ejemplo
└── README.md                        # Este archivo
```

---

## Ejemplos

### 1. Transformer RLM

```python
from models.transformer_rlm import TransformerRLM

# Modelo de gran escala
model = TransformerRLM(
    vocab_size=50000,
    d_model=2048,      # Dimensión grande
    num_heads=32,      # Muchas cabezas
    num_layers=24,     # Muchas capas
    d_ff=8192,         # Muchas neuronas
    max_len=8192       # Secuencias largas
)

# Generar texto
start_tokens = np.array([[1, 2, 3]])
generated = model.generate(start_tokens, max_len=100, temperature=0.8)
```

### 2. Reinforcement Learning (PPO)

```python
from rl.reinforcement_learning import PPOAgent

# Crear agente
agent = PPOAgent(
    state_dim=84,
    action_dim=4,
    learning_rate=0.0003
)

# Entrenar
for episode in range(1000):
    state = env.reset()
    done = False
    
    while not done:
        action = agent.select_action(state)
        next_state, reward, done, _ = env.step(action)
        agent.store_reward(reward, done)
        state = next_state
    
    loss = agent.train_step()
    print(f"Episodio {episode}: Pérdida = {loss:.4f}")
```

### 3. vLLM (Inferencia Rápida)

```python
from vllm.relational_vllm import vLLM

# Crear vLLM
vllm_engine = vLLM(model, max_batch_size=8)

# Generar en batch
prompts = [
    np.array([1, 2, 3]),
    np.array([4, 5, 6, 7]),
    np.array([8, 9])
]

results = vllm_engine.batch_generate(
    prompts,
    max_new_tokens=50,
    temperature=0.7,
    top_k=50,
    top_p=0.9
)
```

### 4. Control de Entrenamiento

```python
from minitorch_lite import create_training_controller

# Crear controlador
controller = create_training_controller(
    max_iterations=69,
    early_stop=True,
    early_stop_patience=12,
    max_tokens=10
)

# Bucle de entrenamiento
while controller.should_continue():
    loss = train_step(data)
    controller.update(loss, tokens_processed=batch_size)

# Guardar checkpoint
controller.save_checkpoint(model.state_dict())
```

---

## Configuración

Edita `config.json` para personalizar:

```json
{
  "model": {
    "vocab_size": 50000,
    "d_model": 512,
    "num_heads": 8,
    "num_layers": 6,
    "d_ff": 2048
  },
  "training": {
    "batch_size": 32,
    "learning_rate": 0.0001,
    "max_iterations": 69,
    "early_stop_patience": 12
  }
}
```

---

## Documentación

- **Manual Completo**: `docs/MANUAL_DE_USO.md`
- **Código Fuente**: Todos los módulos están documentados con docstrings
- **Ejemplos**: `examples/train_complete_model.py`

---

## Características Avanzadas

### Opciones de Control de Entrenamiento

| Opción | Descripción | Valor por Defecto |
|--------|-------------|-------------------|
| `max_iterations` | Máximo de iteraciones | 69 |
| `early_stop_patience` | [NEW] Iteraciones sin mejora | 12 |
| `max_tokens` | Límite de tokens | None |
| `token_limit_iterations` | Máximo con límite de tokens | 12 |

### Backends Soportados

- **NumPy** (por defecto)
- **Numba** (aceleración JIT)
- **JAX** (autograd avanzado)
- **CuPy** (GPU)

### Exportación de Modelos

- **NumPy** (.npz)
- **Keras** (.npz)
- **PyTorch** (.pt)
- **Pickle** (.pkl)

---

## Rendimiento

| Componente | Optimización | Mejora |
|------------|--------------|--------|
| Transformer | Multi-Head Attention | Hasta 8192 neuronas |
| vLLM | KV-Cache | 10x más rápido |
| RL | Experience Replay | Estabilidad mejorada |
| Entrenamiento | Early Stopping | Ahorro de tiempo |

---

## Troubleshooting

### RecursionError en NumPy

```python
from minitorch_lite import set_backend
set_backend('numba')  # O 'jax'
```

### Out of Memory

Reduce `batch_size` o dimensiones del modelo en `config.json`.

### Entrenamiento lento

Usa vLLM y backends acelerados (Numba, JAX).

---

## Licencia

MIT License

---

## Contribuir

Las contribuciones son bienvenidas. Por favor, abre un issue o pull request.

---

## Contacto

- **GitHub**: https://github.com/minitorch/minitorch-framework
- **Email**: minitorch@example.com

---

**Autor**: MiniTorch Framework Team  
**Versión**: 1.0.0  
**Fecha**: 2026
