"""
MiniTorch Framework - Transformer RLM (Reinforcement Learning Model)
====================================================================
Arquitectura Transformer optimizada para Reinforcement Learning con muchas neuronas.

Características:
- Multi-Head Self-Attention con hasta 64 cabezas
- Feed-Forward Networks con hasta 8192 neuronas ocultas
- Layer Normalization y Residual Connections
- Positional Encoding
- Soporte para secuencias largas (hasta 8192 tokens)
"""

import numpy as np
import sys
sys.path.insert(0, '/home/ubuntu')
from minitorch_lite import Module, Parameter, Tensor, Linear, Dropout, Softmax
from typing import Optional, Tuple

class MultiHeadAttention(Module):
    """
    Multi-Head Self-Attention con muchas cabezas para capturar relaciones complejas.
    
    Args:
        d_model: Dimensión del modelo
        num_heads: Número de cabezas de atención (recomendado: 8-64)
        dropout: Tasa de dropout
    """
    
    def __init__(self, d_model: int = 512, num_heads: int = 8, dropout: float = 0.1):
        super().__init__()
        
        assert d_model % num_heads == 0, "d_model debe ser divisible por num_heads"
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        
        # Proyecciones lineales para Q, K, V
        self.W_q = Linear(d_model, d_model)
        self.W_k = Linear(d_model, d_model)
        self.W_v = Linear(d_model, d_model)
        self.W_o = Linear(d_model, d_model)
        
        self.dropout = Dropout(dropout)
        self.softmax = Softmax(dim=-1)
        
        self._modules['W_q'] = self.W_q
        self._modules['W_k'] = self.W_k
        self._modules['W_v'] = self.W_v
        self._modules['W_o'] = self.W_o
        self._modules['dropout'] = self.dropout
    
    def split_heads(self, x: Tensor, batch_size: int) -> np.ndarray:
        """Divide la última dimensión en (num_heads, d_k)."""
        # x shape: (batch_size, seq_len, d_model)
        x_data = x.data.reshape(batch_size, -1, self.num_heads, self.d_k)
        # Transponer a (batch_size, num_heads, seq_len, d_k)
        return np.transpose(x_data, (0, 2, 1, 3))
    
    def forward(self, x: Tensor, mask: Optional[np.ndarray] = None) -> Tensor:
        """
        Forward pass de Multi-Head Attention.
        
        Args:
            x: Tensor de entrada (batch_size, seq_len, d_model)
            mask: Máscara de atención (opcional)
        
        Returns:
            Tensor de salida (batch_size, seq_len, d_model)
        """
        batch_size = x.shape[0]
        seq_len = x.shape[1]
        
        # Proyecciones lineales
        Q = self.W_q(x)
        K = self.W_k(x)
        V = self.W_v(x)
        
        # Dividir en múltiples cabezas
        Q_split = self.split_heads(Q, batch_size)
        K_split = self.split_heads(K, batch_size)
        V_split = self.split_heads(V, batch_size)
        
        # Scaled Dot-Product Attention
        # scores = Q @ K^T / sqrt(d_k)
        scores = np.matmul(Q_split, np.transpose(K_split, (0, 1, 3, 2))) / np.sqrt(self.d_k)
        
        # Aplicar máscara si existe
        if mask is not None:
            scores = scores + (mask * -1e9)
        
        # Softmax
        attention_weights = np.exp(scores - np.max(scores, axis=-1, keepdims=True))
        attention_weights = attention_weights / np.sum(attention_weights, axis=-1, keepdims=True)
        
        # Aplicar dropout
        if self._training:
            dropout_mask = (np.random.rand(*attention_weights.shape) > 0.1).astype(np.float32)
            attention_weights = attention_weights * dropout_mask / 0.9
        
        # Aplicar atención a V
        context = np.matmul(attention_weights, V_split)
        
        # Concatenar cabezas
        context = np.transpose(context, (0, 2, 1, 3))
        context = context.reshape(batch_size, seq_len, self.d_model)
        
        # Proyección final
        output = self.W_o(Tensor(context, requires_grad=x.requires_grad))
        
        return output

class FeedForward(Module):
    """
    Feed-Forward Network con muchas neuronas para capturar patrones complejos.
    
    Args:
        d_model: Dimensión del modelo
        d_ff: Dimensión de la capa oculta (recomendado: 2048-8192)
        dropout: Tasa de dropout
    """
    
    def __init__(self, d_model: int = 512, d_ff: int = 2048, dropout: float = 0.1):
        super().__init__()
        
        self.linear1 = Linear(d_model, d_ff)
        self.linear2 = Linear(d_ff, d_model)
        self.dropout = Dropout(dropout)
        
        self._modules['linear1'] = self.linear1
        self._modules['linear2'] = self.linear2
        self._modules['dropout'] = self.dropout
    
    def forward(self, x: Tensor) -> Tensor:
        # FFN(x) = max(0, xW1 + b1)W2 + b2
        x = self.linear1(x)
        # ReLU
        x_data = np.maximum(0, x.data)
        x = Tensor(x_data, requires_grad=x.requires_grad)
        x = self.dropout(x)
        x = self.linear2(x)
        return x

class LayerNorm(Module):
    """
    Layer Normalization para estabilizar el entrenamiento.
    """
    
    def __init__(self, d_model: int, eps: float = 1e-6):
        super().__init__()
        
        self.gamma = Parameter(np.ones(d_model, dtype=np.float32))
        self.beta = Parameter(np.zeros(d_model, dtype=np.float32))
        self.eps = eps
        
        self._parameters['gamma'] = self.gamma
        self._parameters['beta'] = self.beta
    
    def forward(self, x: Tensor) -> Tensor:
        mean = np.mean(x.data, axis=-1, keepdims=True)
        std = np.std(x.data, axis=-1, keepdims=True)
        
        normalized = (x.data - mean) / (std + self.eps)
        output = self.gamma.data * normalized + self.beta.data
        
        return Tensor(output, requires_grad=x.requires_grad)

class TransformerBlock(Module):
    """
    Bloque Transformer con Self-Attention y Feed-Forward.
    """
    
    def __init__(self, d_model: int = 512, num_heads: int = 8, 
                 d_ff: int = 2048, dropout: float = 0.1):
        super().__init__()
        
        self.attention = MultiHeadAttention(d_model, num_heads, dropout)
        self.ffn = FeedForward(d_model, d_ff, dropout)
        self.norm1 = LayerNorm(d_model)
        self.norm2 = LayerNorm(d_model)
        self.dropout = Dropout(dropout)
        
        self._modules['attention'] = self.attention
        self._modules['ffn'] = self.ffn
        self._modules['norm1'] = self.norm1
        self._modules['norm2'] = self.norm2
        self._modules['dropout'] = self.dropout
    
    def forward(self, x: Tensor, mask: Optional[np.ndarray] = None) -> Tensor:
        # Self-Attention con residual connection
        attn_output = self.attention(x, mask)
        x_data = x.data + self.dropout(attn_output).data
        x = Tensor(x_data, requires_grad=x.requires_grad)
        x = self.norm1(x)
        
        # Feed-Forward con residual connection
        ffn_output = self.ffn(x)
        x_data = x.data + self.dropout(ffn_output).data
        x = Tensor(x_data, requires_grad=x.requires_grad)
        x = self.norm2(x)
        
        return x

class PositionalEncoding(Module):
    """
    Positional Encoding para inyectar información de posición.
    """
    
    def __init__(self, d_model: int, max_len: int = 8192):
        super().__init__()
        
        # Crear matriz de positional encoding
        pe = np.zeros((max_len, d_model), dtype=np.float32)
        position = np.arange(0, max_len, dtype=np.float32).reshape(-1, 1)
        div_term = np.exp(np.arange(0, d_model, 2, dtype=np.float32) * 
                         -(np.log(10000.0) / d_model))
        
        pe[:, 0::2] = np.sin(position * div_term)
        pe[:, 1::2] = np.cos(position * div_term)
        
        self.pe = pe
    
    def forward(self, x: Tensor) -> Tensor:
        seq_len = x.shape[1]
        x_data = x.data + self.pe[:seq_len, :]
        return Tensor(x_data, requires_grad=x.requires_grad)

class TransformerRLM(Module):
    """
    Transformer RLM (Reinforcement Learning Model) completo.
    
    Arquitectura de gran escala para tareas de RL y generación de lenguaje.
    
    Args:
        vocab_size: Tamaño del vocabulario
        d_model: Dimensión del modelo (recomendado: 512-2048)
        num_heads: Número de cabezas de atención (recomendado: 8-64)
        num_layers: Número de capas Transformer (recomendado: 6-24)
        d_ff: Dimensión de Feed-Forward (recomendado: 2048-8192)
        max_len: Longitud máxima de secuencia
        dropout: Tasa de dropout
    """
    
    def __init__(self, vocab_size: int = 50000, d_model: int = 512, 
                 num_heads: int = 8, num_layers: int = 6, 
                 d_ff: int = 2048, max_len: int = 8192, dropout: float = 0.1):
        super().__init__()
        
        self.d_model = d_model
        self.vocab_size = vocab_size
        
        # Embedding de tokens
        self.token_embedding = Parameter(
            np.random.randn(vocab_size, d_model).astype(np.float32) * 0.02
        )
        self._parameters['token_embedding'] = self.token_embedding
        
        # Positional Encoding
        self.pos_encoding = PositionalEncoding(d_model, max_len)
        self._modules['pos_encoding'] = self.pos_encoding
        
        # Capas Transformer
        self.layers = []
        for i in range(num_layers):
            layer = TransformerBlock(d_model, num_heads, d_ff, dropout)
            self.layers.append(layer)
            self._modules[f'layer_{i}'] = layer
        
        # Capa de salida
        self.output_layer = Linear(d_model, vocab_size)
        self._modules['output_layer'] = self.output_layer
        
        self.dropout = Dropout(dropout)
        self._modules['dropout'] = self.dropout
        
        print(f"[TransformerRLM] Inicializado con:")
        print(f"  - Vocabulario: {vocab_size}")
        print(f"  - Dimensión del modelo: {d_model}")
        print(f"  - Cabezas de atención: {num_heads}")
        print(f"  - Capas: {num_layers}")
        print(f"  - Neuronas Feed-Forward: {d_ff}")
        print(f"  - Parámetros totales: ~{self._count_parameters():,}")
    
    def _count_parameters(self) -> int:
        """Cuenta el número total de parámetros."""
        total = 0
        for param in self.parameters():
            total += np.prod(param.shape)
        return int(total)
    
    def forward(self, x: np.ndarray, mask: Optional[np.ndarray] = None) -> Tensor:
        """
        Forward pass del Transformer RLM.
        
        Args:
            x: Índices de tokens (batch_size, seq_len)
            mask: Máscara de atención (opcional)
        
        Returns:
            Logits de salida (batch_size, seq_len, vocab_size)
        """
        # Embedding de tokens
        batch_size, seq_len = x.shape
        embedded = self.token_embedding.data[x.astype(int)]  # (batch_size, seq_len, d_model)
        embedded = Tensor(embedded, requires_grad=True)
        
        # Positional Encoding
        x = self.pos_encoding(embedded)
        x = self.dropout(x)
        
        # Pasar por capas Transformer
        for layer in self.layers:
            x = layer(x, mask)
        
        # Proyección a vocabulario
        logits = self.output_layer(x)
        
        return logits
    
    def generate(self, start_tokens: np.ndarray, max_len: int = 100, 
                temperature: float = 1.0) -> np.ndarray:
        """
        Genera secuencia de tokens autoregressivamente.
        
        Args:
            start_tokens: Tokens iniciales (batch_size, start_len)
            max_len: Longitud máxima a generar
            temperature: Temperatura de sampling (mayor = más aleatorio)
        
        Returns:
            Secuencia generada (batch_size, max_len)
        """
        self.eval()
        
        generated = start_tokens.copy()
        
        for _ in range(max_len - start_tokens.shape[1]):
            # Forward pass
            logits = self.forward(generated)
            
            # Tomar el último token
            next_token_logits = logits.data[:, -1, :] / temperature
            
            # Softmax
            exp_logits = np.exp(next_token_logits - np.max(next_token_logits, axis=-1, keepdims=True))
            probs = exp_logits / np.sum(exp_logits, axis=-1, keepdims=True)
            
            # Sampling
            next_token = np.array([np.random.choice(self.vocab_size, p=p) for p in probs])
            
            # Añadir a la secuencia
            generated = np.concatenate([generated, next_token.reshape(-1, 1)], axis=1)
        
        self.train()
        return generated
